<?php
header('location: ../');
?>
